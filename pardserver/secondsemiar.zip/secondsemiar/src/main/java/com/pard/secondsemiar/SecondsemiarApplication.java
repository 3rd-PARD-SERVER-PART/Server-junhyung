package com.pard.secondsemiar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecondsemiarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecondsemiarApplication.class, args);
	}

}
